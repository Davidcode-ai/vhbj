# Evidencias — Práctica 1 de Nginx

| Nº | Evidencia | Contenido |
|---:|---|---|
| 0 | [Opción elegida](0.-opcion_elegida.txt) | Forma de diferenciar los sitios (Opción B por nombres). |
| 1 | [Entorno](1.-entorno.txt) | Sistema, CPU, memoria, disco e IP inicial. |
| 2 | [Instalación y estado](2.-instalacion-y-estado.txt) | Versión, servicio, puertos y firewall. |
| 3 | [Arquitectura de ficheros](3.-arquitectura-ficheros.txt) | Rutas, inclusiones y registros. |
| 4 | [Saludo app](4.-saludo-app.txt) | Metadatos, hash y código de `saludo-app`. |
| 5 | [Repetidor app](5.-repetidor-app.txt) | Metadatos, hash y código de `repetidor-app`. |
| 4c | [HTML de saludo](4.-saludo-app.index.html) | Copia del archivo publicado. |
| 5c | [HTML de repetidor](5.-repetidor-app.index.html) | Copia del archivo publicado. |
| 6 | [Configuración de saludo](6.-saludo-app.conf) | Virtual host de `saludo-app`. |
| 7 | [Configuración de repetidor](7.-repetidor-app.conf) | Virtual host de `repetidor-app`. |
| 8 | [Activación y validación](8.-activacion-y-validacion.txt) | Enlaces en `sites-enabled` y `nginx -t`. |
| 9 | [Recarga y estado](9.-recarga-y-estado.txt) | Recarga y estado final del servicio. |
| 10 | [Configuración efectiva](10.-nginx-configuracion-efectiva.txt) | Configuración completa cargada por Nginx. |
| 11 | [Pruebas HTTP](11.-pruebas-http.txt) | Respuestas `curl` de ambos sitios. |
| 12 | [Pruebas funcionales](12.-pruebas-funcionales.txt) | Comprobaciones hechas en Firefox. |
| 13 | [Registros](13.-registros.txt) | `access.log`, `error.log` y `journal`. |
| 14 | [Inventario y validación](14.-inventario-y-validacion.txt) | Verificación final de archivos y enlaces. |
